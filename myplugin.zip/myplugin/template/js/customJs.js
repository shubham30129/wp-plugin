document.getElementById('insert').click(function () {
	// body...
	alert();
});
/*
$('#insert').click(function () {
	alert();
});


bootbox.alert({
	    message: "This is the small alert!",
	    size: 'small'
	});